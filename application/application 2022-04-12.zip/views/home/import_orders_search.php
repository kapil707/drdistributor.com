<style>
.menubtn1
{
	display:none;
}
@media screen and (max-width: 767px) {
	.search_pg_menu_off,.main_home_top_btn
	{
		display:none;
	}
	.current_order_search_page,.delete_btn_icon
	{
		display: block !important;
	}
	<?php if($chemist_id!=""){ ?>
		.headertitle
		{
			display:none;
		}
		.headertitle1
		{
			display: block !important;
		}
		.header_part_search_page_chemist_name
		{
			display: inline-block !important;
		}
	<?php } ?>
}
.deleteicon
{
	display: initial !important;
}
.headertitle
{
    margin-top: 5px !important;
}
.home_page_search_div_box,.select_medicine
{
	display: inline-block;
}
.select_chemist,.home_page_search_div,.search_medicine_result,.clear_search_icon
{
	display: none;
}
</style>
<script>
$(".headertitle").html("Upload order");
function goBack() {
	window.location.href = "<?= base_url();?>import_order";
}
</script>

<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-12 col-12">
			<table class="table table-striped table-bordered" aria-describedby>
				<thead>
					<tr>
						<th style="width:50px;" scope>
							S.No.
						</th>
						<th scope>
							Item Information
						</th>
					</tr>
				</thead>
				<tbody class="tbody_row">
			<?php
			$lastcount=0;
			$j = 0;
			foreach($result as $row)
			{
				$item_name 	= ucwords(strtolower($row->item_name));
				if(!empty($item_name))
				{
					$item_qty 	= $row->quantity;
					$item_mrp 	= $row->mrp;
					$i          = $row->id; 
					$j++?>
					<tr class="remove_css_<?= $i ?>">
						<td>
							<?= $j ?>
							<input type="hidden" value="<?= $item_name ?>" class="your_item_name_<?= $i ?>">
							<input type="hidden" value="<?= $item_mrp ?>" class="your_item_mrp_<?= $i ?>">
							<input type="hidden" value="<?= $item_qty ?>" class="your_item_qty_<?= $i ?>">
						</td>
						<td class="import_order_td_<?= $i ?>">
							<div class="row">
								<div class="col-sm-1">
									<img src="<?=base_url(); ?>img_v<?= constant('site_v') ?>/logo2.png" width="60px;" style="margin-top: 5px;" class="image_css_<?= $i ?> medicine_cart_item_image" alt="" onerror="this.src='<?= base_url(); ?>/uploads/default_img.jpg'">
								</div>
								<div class="col-sm-11">
									<div class="row">
										<div class="col-sm-8">
											<span style="float:left;">
												<?= $myname;?> : 
												<span class="import_order_title_1 medicine_cart_item_name">
												<?= $item_name; ?>
												</span>
											</span>
											<span style="float:left; margin-left:10px;margin-right:10px;" class="">
											|
											</span>
											<span style="float:left;"><a href="javascript:void(0)" onclick="remove_row('<?= $i; ?>')" title="Delete medicine" class="cart_delete_btn">
											<img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" alt="Delete medicine"> Delete medicine</a>
											</span>
										</div>
										<div class="col-sm-4 text-right">
											<span style="float:right;">
											<div class="import_order_mrp medicine_cart_item_mrp">MRP. : <i class="fa fa-inr" aria-hidden="true"></i> <?= number_format($item_mrp,2) ?>/-</div>
											</span>
											<span style="float:right; margin-left:10px;margin-right:10px;" class="import_order_mrp">
											|
											</span>
											<span style="float:right;">
												<input type="number" name="item_qty[]" value="<?= $item_qty ?>" class="form-control new_quantity item_qty_<?= $i ?>" style="width: 50px;height: 30px;font-size: 12px;padding: 3px;" onchange="change_item_qty('<?= $i; ?>')" min="1" max="1000" />
											</span>
											<span style="float:right;margin-right:5px;" class="cart_order_qty1">
											Quantity : 
											</span>
										</div>
										<div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div>
									</div>
									<div class="row select_product_<?= $i ?>" style="display:none">
										<div class="col-sm-8">
											DRD : 
											<span class="medicine_cart_item_name selected_item_name_<?= $i ?>"></span>
											<span class="medicine_cart_item_packing">
											(<span class="selected_packing_<?= $i ?>"></span> Packing) </span> - <span class="medicine_cart_item_expiry expiry_css_<?= $i ?>"> Expiry : <span class="selected_expiry_<?= $i ?>"></span></span>
										</div>
										<div class="col-sm-4 text-right">
											<span class="medicine_cart_item_stock">
											Stock : <span class="selected_batchqty_<?= $i ?>"></span></span> | 
											<span class="medicine_cart_item_mrp">
											MRP. : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_mrp_<?= $i ?>">0.00</span>/- </span>
										</div>	
										<div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div>
										<div class="col-sm-7">
											<span class="medicine_cart_item_company">
											By : <span class="selected_company_full_name_<?= $i ?>"></span></span> 
											|  <span class="medicine_cart_item_batch_no"> Batch no : <span class="selected_batch_no_<?= $i ?>"></span></span>
											<span class="select_product_<?= $i ?> selected_scheme_span_<?= $i ?>"> | 
												<span class="medicine_cart_item_scheme selected_scheme_<?= $i ?>"></span>
											</span>
										</div>
										<div class="col-sm-5 text-right">
											<span class="medicine_cart_item_ptr">
											PTR : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_sale_rate_<?= $i ?>">0.00</span>/-</span> | 
											<span class="medicine_cart_item_price">
											~ Landing price : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_final_price_<?= $i ?>">0.00</span>/-</span>
										</div>
									</div>
								</div>
								<div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div>
								<div class="col-sm-12">
									<span class="cart_description1 selected_msg_<?= $i ?>"> Loading.... </span>
									<span class="selected_SearchAnotherMedicine_<?= $i ?>" style="display:none">
										<a href="javascript:Search_Another_Medicine_js('<?= $i ?>')" class="cart_delete_btn" title="Change medicine">
										<img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/edit_icon.png" width="18px;" alt="Change Medicine">
											Change medicine
										</a>
									</span>
									<span class="selected_suggest_<?= $i ?>" style="display:none">
									|
										<a href="javascript:delete_suggest('<?= $i ?>')" title="Delete suggested medicine" class="cart_delete_btn"><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" alt="Delete suggested medicine">Delete suggested medicine</a>
									</span>
								</div>
							</div>
							<?php /***main result show hear*/ ?>
							<span class="import_order_dropdownbox_<?= $i ?>"></span>
						</td>
					</tr>
					<script>
					$(document).ready(function(){
						setTimeout("import_order_dropdownbox('<?= $i ?>')",500);
					});
					</script>
				<?php
				$lastcount++;
				}
			}
			?>
				</tbody>
			</table>
		</div>
		<div class="col-sm-6 col-6 text-left">
			<button type="submit" class="btn btn-primary mainbutton next_btn" name="submit" value="submit" onclick="add_new_medicine()" style="width:30%"> + Add Medicine</button>
		</div>
		<div class="col-sm-6 col-6 text-right">
			<a href="<?= base_url(); ?>import_order/delete_items/<?php echo base64_encode($order_id); ?>/<?php echo $chemist_id; ?>">
				<button type="submit" class="btn btn-primary mainbutton next_btn" name="submit" value="submit" style="width:20%">Next</button>
			</a>
		</div>		
	</div>     
</div>
<input type="hidden" class="_import_order_i">
<div class="background_blur" onclick="clear_search_icon()" style="display:none"></div>
<div class="script_css"></div>
<input type="hidden" value="<?php echo $chemist_id; ?>" class="chemist_id" id="chemist_id">
<input type="hidden" value="<?php echo time(); ?>" class="mytime">

<input type="hidden" value="" class="new_import_page_item_name">
<input type="hidden" value="" class="new_import_page_item_mrp">
<script>
function change_item_qty(cssid)
{
	item_qty = $(".item_qty_"+cssid).val();
	$(".your_item_qty_"+cssid).val(item_qty);
	$.ajax({
		type       : "POST",
		data       :  {item_qty:item_qty,cssid:cssid,chemist_id:'<?= $chemist_id ?>',order_id:'<?php echo $order_id ?>'} ,
		url        : "<?= base_url(); ?>import_order/change_item_qty",
		cache	   : false,
		error: function(){
			swal("Quantity not updated");
		},
		success    : function(data){
			$.each(data.items, function(i,item){	
				if (item)
				{
					if(item.response=="1")
					{
						swal("Quantity updated successfully");
					}
					else{
						swal("Quantity not updated");
					}
				} 
			});
		},
		timeout: 10000
	});
}

function import_order_dropdownbox(cssid)
{
	item_name = $(".your_item_name_"+cssid).val();
	item_mrp  = $(".your_item_mrp_"+cssid).val();
	item_qty  = $(".your_item_qty_"+cssid).val();

	mytime = $(".mytime").val();
	$.ajax({
		type       : "POST",
		data       :  {item_name:item_name,item_mrp:item_mrp,item_qty:item_qty,mytime:mytime,cssid:cssid,chemist_id:'<?= $chemist_id ?>',order_id:'<?php echo $order_id ?>'} ,
		url        : "<?= base_url(); ?>import_order/import_order_dropdownbox",
		cache	   : false,
		error: function(){
			$(".selected_msg_"+cssid).html("Server not Responding, Please try Again");
		},
		success    : function(data){
			$(".import_order_dropdownbox_"+cssid).html(data);
		}
	});
}

function remove_row(cssid)
{
	item_name = $(".your_item_name_"+cssid).val();
	swal({
		title: "Are you sure to delete medicine?",
		/*text: "Once deleted, you will not be able to recover this imaginary file!",*/
		icon: "warning",
		buttons: ["No", "Yes"],
		dangerMode: true,
	}).then(function(result) {
		if (result) {
			$.ajax({
				type       : "POST",
				data       :  {cssid:cssid,item_name:item_name,chemist_id:'<?= $chemist_id ?>',order_id:'<?php echo $order_id ?>',} ,
				url        : "<?= base_url(); ?>import_order/remove_row",
				cache	   : false,
				error: function(){
					swal("Medicine not deleted");
				},
				success    : function(data){
					$.each(data.items, function(i,item){	
						if (item)
						{
							if(item.response=="1")
							{
								$(".remove_css_"+cssid).html('');
								swal("Medicine deleted successfully", {
									icon: "success",
								});
							}
							else{
								swal("Medicine not deleted");
							}
						} 
					});
				},
				timeout: 10000
			});
		} else {
			swal("Medicine not deleted");
		}
	});
}

function delete_suggest(cssid)
{
	item_name = $(".your_item_name_"+cssid).val();
	item_mrp  = $(".your_item_mrp_"+cssid).val();
	item_qty  = $(".your_item_qty_"+cssid).val();
	swal({
		title: "Are you sure to delete suggested medicine?",
		/*text: "Once deleted, you will not be able to recover this imaginary file!",*/
		icon: "warning",
		buttons: ["No", "Yes"],
		dangerMode: true,
	}).then(function(result) {
		if (result) {
			$.ajax({
				url: "<?php echo base_url(); ?>import_order/delete_suggest",
				type:"POST",
				/*dataType: 'html',*/
				data: {item_name:item_name},
				error: function(){
					swal("Suggested medicine not deleted");
				},
				success: function(data){
					$.each(data.items, function(i,item){	
						if (item)
						{
							if(item.response=="1")
							{
								swal("Suggested Medicine deleted successfully", {
									icon: "success",
								});
								$('.selected_suggest_'+cssid).hide();
								import_order_dropdownbox(cssid,item_name,item_mrp,item_qty)
							}
							else{
								swal("Suggested medicine not deleted");
							}
						} 
					});
				},
				timeout: 10000
			});
		} else {
			swal("Suggested medicine not deleted");
		}
	});
}
/*************************************/

function Search_Another_Medicine_js(cssid)
{
	item_name = $(".your_item_name_"+cssid).val();
	$(".select_chemist").hide();
	$(".select_medicine").focus();
	$(".select_medicine").val('');
	$(".background_blur").show();
	/*$(window).scrollTop(0); 
	$('html, body').css({
		overflow: 'hidden',
		height: '100%'
	});*/
	$("._import_order_i").val(cssid);
	//$('.select_medicine').val(item_name);
	setTimeout($('.select_medicine').val(item_name),500);
	setTimeout(search_medicine(),1000);
}

function clear_search_icon()
{
	$(".clear_search_icon").hide();
	$(".select_medicine").val('');
	$(".background_blur").hide();
	i = $("._import_order_i").val();
	$(".item_qty_"+i).focus();
	$(".search_medicine_result").hide();
	/*$('html, body').css({
		overflow: 'auto',
		height: '100%'
	});*/
}

$(document).ready(function(){	
	$(".search_textbox").keyup(function() { 
		var keyword = $(".search_textbox").val();
		if(keyword!="")
		{
			if(keyword.length<3)
			{
				$('.search_textbox').focus();
				$(".search_medicine_result").html("");
			}
			search_medicine()
		}
		else{
			//clear_search_icon();
		}
	});
	$(".search_textbox").change(function() { 
	});
	$(".search_textbox").on("search", function() { 
	});
	
    $(".search_textbox").keydown(function(event) {
    	if(event.key=="ArrowDown")
    	{
			page_up_down_arrow("1");
    		$('.hover_1').attr("tabindex",-1).focus();
			return false;
    	}
    });
	//setTimeout('page_load();',100);
	
	document.onkeydown = function(evt) {
		evt = evt || window.event;
		if (evt.keyCode == 27) {
			//clear_search_icon();
		}
	};
});

function search_medicine()
{
	new_i = 0;
	$(".clear_search_icon").show();
	var keyword = $(".search_textbox").val();
	if(keyword!="")
	{
		if(keyword=="#")
		{
			keyword = "k1k2k12k";
		}
		if(keyword.length>2)
		{
			$(".background_blur").show();
			$(".search_medicine_result").show();
			$(".search_medicine_result").html('<div class="row p-2" style="background:white;"><div class="col-sm-12 text-center"><h1><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px"></h1><h1>Loading....</h1></div></div>');
			$.ajax({
				type       : "POST",
				data       :  { keyword : keyword} ,
				url        : "<?php echo base_url(); ?>Chemist_medicine/medicine_search_api",
				error: function(){
					$(".search_medicine_result").html('<h1><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/something_went_wrong.png" width="100%"></h1>');
				},
				cache	   : false,
				success    : function(data){
					if(data.items=="")
					{
						$(".search_medicine_result").html('<div class="row p-2" style="background:white;"><div class="col-sm-12 text-center"><h1><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/no_record_found.png" width="100%"></h1></div></div>');
					}
					else
					{
						$(".search_medicine_result").html("");
					}
					$.each(data.items, function(i,item){
						if (item)
						{
							item_code			= item.item_code;
							item_image			= item.item_image;			
							item_name 			= item.item_name;
							item_packing 		= item.item_packing;
							item_expiry 		= item.item_expiry;
							item_company 		= item.item_company;
							item_quantity 		= item.item_quantity;
							item_stock 			= item.item_stock;
							item_ptr 			= item.item_ptr;
							item_mrp 			= item.item_mrp;
							item_price 			= item.item_price;
							item_scheme 		= item.item_scheme;
							item_margin 		= item.item_margin;
							item_featured 		= item.item_featured;
							item_description1 	= item.item_description1;
							similar_items 		= item.similar_items;
							
							div_start = 'onClick=select_medicine_in_search_box("'+item_code+'"),clear_search_icon()';

							new_i = parseInt(new_i) + 1;
							csshover1 = 'hover_'+new_i;

							div_all_data = "<div class='medicine_details_all_data_"+item_code+"' item_image='"+item_image+"' item_name='"+item_name+"' item_packing='"+item_packing+"' item_expiry='"+item_expiry+"' item_company='"+item_company+"' item_quantity='"+item_quantity+"' item_stock='"+item_stock+"' item_ptr='"+item_ptr+"' item_mrp='"+item_mrp+"' item_price='"+item_price+"' item_scheme='"+item_scheme+"' item_margin='"+item_margin+"' item_featured='"+item_featured+"' item_description1='"+item_description1+"' similar_items='"+similar_items+"'></div>"
							
							item_scheme_div = "";
							if(item_scheme!="0+0")
							{
								item_scheme_div =  ' | <span class="medicine_cart_item_scheme">Scheme : '+item_scheme+'</span>';
							}

							item_other_image_div = '';
							if(item_featured=="1" && item_quantity!="0"){
								item_other_image_div = '<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/featured_img.png" class="medicine_cart_item_featured_img">';
							}

							item_quantity_div = '<span class="medicine_cart_item_out_of_stock">Out of stock</span>';
							if(item_quantity=="0"){
								item_other_image_div = '<img src="<?= base_url() ?>img_v<?= constant('site_v') ?>/out_of_stock_img.png" class="medicine_cart_item_out_of_stock_img">';
							} 
							else 
							{
								item_quantity_div = '<span class="medicine_cart_item_stock">Stock : '+item_quantity+'</span>' + item_scheme_div;
								if(item_stock!="")
								{
									item_quantity_div = '<span class="medicine_cart_item_stock">'+item_stock+'</span>' + item_scheme_div;
								}
							}

							error_img ="onerror=this.src='<?= base_url(); ?>/uploads/default_img.jpg'"

							item_image_div = item_other_image_div+'<img src="'+item_image+'" class="medicine_cart_item_image" '+error_img+'>';
							
							rete_div =  '<span class="medicine_cart_item_ptr">PTR : <i class="fa fa-inr" aria-hidden="true"></i> '+item_ptr+'/- </span> | <span class="medicine_cart_item_mrp">MRP : <i class="fa fa-inr" aria-hidden="true"></i> '+item_mrp+'/- </span> | <span class="medicine_cart_item_price"> ~ Price : <i class="fa fa-inr" aria-hidden="true"></i> '+item_price+'/- </span>';
							

							$(".search_medicine_result").append('<div class="main_theme_li_bg '+csshover1+' medicine_details_funcation_'+new_i+'" '+div_start+'><div class="medicine_search_div1">'+item_image_div+'</div><div class="medicine_search_div2"><div class="medicine_cart_item_name">'+item_name+'<span class="medicine_cart_item_packing mobile_off"> ('+item_packing+' Packing)</span></div><div class="medicine_cart_item_packing mobile_show">'+item_packing+' Packing</div><div class=""><span class="medicine_cart_item_margin">'+item_margin+'% Margin </span>| <span class="medicine_cart_item_expiry">Expiry : '+item_expiry+'</span></div><div class="medicine_cart_item_company">By '+item_company+'</div><div>'+item_quantity_div+'</div><div class="mobile_off">'+rete_div+'</div></div><div class="cart_ki_main_div3 mobile_show" style="margin-left:5px;">'+rete_div+'</div><div class="cart_ki_main_div3 medicine_cart_item_description1" style="margin-left:5px;">'+item_description1+'</div></div>'+div_all_data);
						}
					});
				},
				timeout: 3000
			});
		}
		else{
			$(".clear_search_icon").hide();
			$(".search_medicine_result").html("");
		}
	}
}

function page_up_down_arrow(new_i)
{
	$('.hover_'+new_i).keypress(function (e) {
		 if (e.which == 13) {
			$('.get_single_medicine_info_'+new_i).click();
		 } 						 
	 });
	$('.hover_'+new_i).keydown(function(event) {
		if(event.key=="ArrowDown")
		{
			new_i = parseInt(new_i) + 1;
			page_up_down_arrow(new_i);
			$('.hover_'+new_i).attr("tabindex",-1).focus();
			return false;
		}
		if(event.key=="ArrowUp")
		{
			if(parseInt(new_i)==1)
			{
				$('.search_textbox').focus();
			}
			else
			{
				new_i = parseInt(new_i) - 1;
				page_up_down_arrow(new_i);
				$('.hover_'+new_i).attr("tabindex",-1).focus();
			}
			return false;
		}
	});
}

function add_new_medicine()
{
	clear_search_icon();
	$(".select_medicine").focus();
	$(".background_blur").show();
	$(".clear_search_icon").show();
}

function select_medicine_in_search_box(new_i_code)
{	
	new_i = $("._import_order_i").val();
	var your_item_name = $(".your_item_name_"+new_i).val();
	var your_item_mrp  = $(".your_item_mrp_"+new_i).val();
	var your_item_qty  = $(".your_item_qty_"+new_i).val();
	if(new_i!="")
	{
		$.ajax({
			url: "<?php echo base_url(); ?>import_order/select_medicine_in_search_box",
			type:"POST",
			/*dataType: 'html',*/
			data: {new_i_code:new_i_code,your_item_name:your_item_name},
			error: function(){
				swal("Medicine not changed");
			},
			success: function(data){
					$.each(data.items, function(i,item){	
					if (item)
					{
						if(item.response=="1")
						{
							setTimeout("import_order_dropdownbox('"+new_i+"','<?= '"+your_item_name+"' ?>','"+your_item_mrp+"','"+your_item_qty+"')",200);
							$("._import_order_i").val('');
							swal("Medicine changed successfully", {
								icon: "success",
							});
						}
						else{
							swal("Medicine not changed");
						}
					} 
				});
			},
			timeout: 10000
		});
	}
	else{
		get_single_medicine_info(new_i_code);
	}
}

var js_i = "";
var js_j = "";
function add_new_row_import_order_page(item_name,mrp,item_qty)
{
	item_name = atob(item_name); // ok check me 2021-05-18
	mrp1 = parseFloat(mrp).toFixed(2);
	if(js_i=="")
	{
		js_i = parseInt("<?= $i; ?>");
		js_j = parseInt("<?= $j; ?>");
	}
	
	js_i++;
	js_j++;
	
	js1 = "javascript:Search_Another_Medicine_js('"+js_i+"')";
	js2 = "javascript:delete_suggest('"+js_i+"')";

	$(".tbody_row").append('<tr class="remove_css_'+js_i+'"><td>'+js_j+'<input type="hidden" value="'+item_name+'" class="your_item_name_'+js_i+'"><input type="hidden" value="'+mrp+'" class="your_item_mrp_'+js_i+'"><input type="hidden" value="'+item_qty+'" class="your_item_qty_'+js_i+'"></td><td class="import_order_td_'+js_i+'"><div class="row"><div class="col-sm-1"><img src="<?=base_url(); ?>img_v<?= constant('site_v') ?>/logo2.png" width="60px;" style="margin-top: 5px;" class="image_css_'+js_i+'" alt=""></div><div class="col-sm-11"><div class="row"><div class="col-sm-8"><span style="float:left;"><?= $myname;?> : <span class="import_order_title_1"> '+item_name+'</span> </span> <span style="float:left; margin-left:10px;margin-right:10px;" class="import_order_mrp"> | </span> <span style="float:left;"><a href="javascript:void(0)" onclick="remove_row('+js_i+')" title="Delete medicine" class="cart_delete_btn"> <img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" alt="Delete medicine"> Delete medicine</a> </span> </div> <div class="col-sm-4 text-right"> <span style="float:right;"> <div class="import_order_mrp">MRP. : <i class="fa fa-inr" aria-hidden="true"></i> '+mrp1+'/-</div> </span> <span style="float:right; margin-left:10px;margin-right:10px;" class="import_order_mrp"> | </span> <span style="float:right;"> <input type="number" name="item_qty[]" value="'+item_qty+'" class="form-control item_qty_'+js_i+'" style="width: 50px;height: 30px;font-size: 12px;padding: 3px;" onchange="change_item_qty('+js_i+')" min="1" max="1000" /> </span> <span style="float:right;margin-right:5px;" class="cart_order_qty1"> Quantity : </span> </div> <div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div> </div> <div class="row select_product_'+js_i+'" style="display:none"> <div class="col-sm-8"> DRD :  <span class="import_order_title selected_item_name_'+js_i+'"></span> <span class="import_order_packing"> (<span class="selected_packing_'+js_i+'"></span> Packing) </span> - <span class="import_order_expiry expiry_css_'+js_i+'"> Expiry : <span class="selected_expiry_'+js_i+'"></span></span> </div> <div class="col-sm-4 text-right"> <span class="import_order_stock"> Stock : <span class="selected_batchqty_'+js_i+'"></span></span> | <span class="import_order_mrp"> MRP. : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_mrp_'+js_i+'">0.00</span>/- </span> </div>	<div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div> <div class="col-sm-7"> <span class="import_order_company"> By : <span class="selected_company_full_name_'+js_i+'"></span></span> |  <span class="import_order_batch_no"> Batch No : <span class="selected_batch_no_'+js_i+'"></span></span> <span class="select_product_'+js_i+' selected_scheme_span_'+js_i+'"> |  <span class="import_order_scheme selected_scheme_'+js_i+'"></span> </span> </div> <div class="col-sm-5 text-right"> <span class="import_order_ptr"> PTR : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_sale_rate_'+js_i+'">0.00</span>/-</span> | <span class="import_order_landing_price"> ~ Landing price : <i class="fa fa-inr" aria-hidden="true"></i> <span class="selected_final_price_'+js_i+'">0.00</span>/-</span> </div> </div> </div> <div class="col-sm-12" style=" border-top-style: solid;border-top-color: #dee2e6;border-top-width: 1px;"></div> <div class="col-sm-12"> <span class="selected_msg_'+js_i+'"> Loading.... </span> <span class="selected_SearchAnotherMedicine_'+js_i+'" style="display:none">  | <a href="'+js1+'" class="cart_delete_btn" title="Change medicine"> <img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/edit_icon.png" width="18px;" alt="Change medicine"> Change medicine </a> </span> <span class="selected_suggest_'+js_i+'" style="display:none"> | <a href="'+js2+'" title="Delete Suggest Medicine" class="cart_delete_btn"><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" alt="Delete Suggest Medicine">Delete Suggest Medicine</a> </span> </div> </div> <span class="import_order_dropdownbox_'+js_i+'"></span> </td> </tr>');

	setTimeout("import_order_dropdownbox('"+js_i+"','"+item_name+"','"+mrp+"','"+item_qty+"')",1000);
}
</script>
<script src="<?= base_url(); ?>assets/website/select_css/chosen.jquery.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/website/select_css/init.js" type="text/javascript" charset="utf-8"></script>