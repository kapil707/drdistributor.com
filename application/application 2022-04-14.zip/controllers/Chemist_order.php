<?php
header('Content-Type: application/json');
defined('BASEPATH') OR exit('No direct script access allowed');
class Chemist_order extends CI_Controller
{
	public function get_temp_rec($chemist_id)
	{
		$user_altercode = $this->session->userdata('user_altercode');
		$user_type 		= $this->session->userdata('user_type');
		if($user_type=="sales")
		{
			$temp_rec = $user_type."_".$user_altercode."_".$chemist_id;
		}
		else
		{
			$temp_rec = $user_type."_".$user_altercode;
		}
		return $temp_rec;
	}
	
	public function add_medicine_to_cart(){
		//error_reporting(0);
		$items = "";
		$user_type 		= $this->session->userdata('user_type');
		$user_altercode	= $this->session->userdata('user_altercode');
		$i_code 		= $_POST['i_code'];
		$quantity 		= $_POST['quantity'];
		$chemist_id		= $_POST['chemist_id']; //only for sales man time
		
		$item_name = base64_decode($_POST["item_name"]);
		$sale_rate = ($_POST["final_price"]);
		$scheme    = base64_decode($_POST["scheme"]);
		$image     = ($_POST["image"]);
		/**********************************************/
		
		$time = time();
		$date = date("Y-m-d",$time);
		$datetime = date("d-M-y H:i",$time);
				
		$temp_rec = $this->get_temp_rec($chemist_id);
		$row = $this->db->query("select * from drd_temp_rec where temp_rec='$temp_rec' and status='0' order by excel_number desc")->row();
		if(!empty($row->excel_temp_id))
		{
			$excel_temp_id = $row->excel_temp_id;
		}
		else
		{
			$mytime = time();
			$excel_temp_id	= $temp_rec."_pc_mobile_".$mytime;
		}
		$excel_number_x = 0;
		if(!empty($row->excel_number))
		{
			$excel_number_x = $row->excel_number;
		}
		$excel_number = intval($excel_number_x) + 1;
		$selesman_id = "";
		if($user_type=="sales")
		{
			$selesman_id = $user_altercode;
		}
		else
		{
			$chemist_id  = $user_altercode;
		}
		if(!empty($i_code) && !empty($quantity))
		{
			$mobilenumber = "";
			$modalnumber = "PC / Laptop";

			/********************old cart m medicine ko delete karta h yha**/
			$where = array('chemist_id'=>$chemist_id,'selesman_id'=>$selesman_id,'user_type'=>$user_type,'i_code'=>$i_code,'status'=>'0');
			$row = $this->Scheme_Model->select_row("drd_temp_rec",$where);
			if(!empty($row->id))
			{
				$this->db->query("update drd_temp_rec set quantity='$quantity' where id='$row->id'");
				$response = 1;
			}
			else
			{
				$where = array('i_code'=>$i_code);
				$row = $this->Scheme_Model->select_row("tbl_medicine",$where);
				
				$order_type = "pc_mobile";
				$dt = array(
					'i_code'=>$i_code,
					'quantity'=>$quantity,

					'item_name'=>$item_name,
					'company_full_name'=>$row->company_full_name,
					'packing'=>$row->packing,
					'expiry'=>$row->expiry,
					'image'=>$image,
					'sale_rate'=>$sale_rate,
					'scheme'=>$scheme,
					
					'chemist_id'=>$chemist_id,
					'selesman_id'=>$selesman_id,
					'user_type'=>$user_type,
					'date'=>$date,
					'time'=>$time,
					'datetime'=>$datetime,
					'temp_rec'=>$temp_rec,
					'order_type'=>$order_type,
					'mobilenumber'=>$mobilenumber,
					'modalnumber'=>$modalnumber,
					'excel_temp_id'=>$excel_temp_id,
					
					'excel_number'=>$excel_number,
				);
				
				if(!empty($row->id))
				{
					$response = $this->Scheme_Model->insert_fun("drd_temp_rec",$dt);
					if($response!=0 || !empty($response))
					{
						$response = 1;
					}
				}
			}
			
$items.= <<<EOD
{"response":"{$response}"},
EOD;
        }
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}
	
	public function add_low_stock_alert()
	{	
		$user_type 		= $this->session->userdata('user_type');
		$user_altercode	= $this->session->userdata('user_altercode');
		$i_code 		= $_POST['i_code'];
		
		$selesman_id = "";
		if($user_type=="sales")
		{
			$selesman_id = $user_altercode;
		}
		else
		{
			$chemist_id  = $user_altercode;
		}

		$date 			= date('Y-m-d');
		$time 			= time();
		if($user_type=="sales")
		{
			$where = array('altercode'=>$chemist_id,);
			$qr = $this->Scheme_Model->select_row("tbl_acm",$where);

			$title 			= ucwords(strtolower($qr->name));
			$chemist_name 	= "$title - ($chemist_id)";	
			$acm_email 		= $qr->email;

			$where = array('customer_code'=>$selesman_id,);
			$qr = $this->Scheme_Model->select_row("tbl_users",$where);
			
			$name 			= ucwords(strtolower($qr->firstname." ".$qr->lastname));
			$salesman_name 	= "$name - ($qr->customer_code)";
		}
		if($user_type=="chemist")
		{			
			$where = array('altercode'=>$chemist_id,);
			$qr = $this->Scheme_Model->select_row("tbl_acm",$where);

			$title 			= ucwords(strtolower($qr->name));
			$chemist_name 	= "$title - ($qr->altercode)";
			$acm_email 		= $qr->email;
		}
		
		$where = array('i_code'=>$i_code);
		$row = $this->Scheme_Model->select_row("tbl_medicine",$where);
		if(!empty($row->item_name))
		{
			$item_name = $row->item_name;
			$item_code = $row->item_code;
			
			$where1 = array('i_code'=>$i_code,'date'=>$date,);
			$row1 = $this->Scheme_Model->select_row("tbl_low_stock_alert",$where1);
			if(empty($row1->i_code))
			{
				$dt = array(
				'user_type'=>$user_type,
				'chemist_id'=>$chemist_id,
				'selesman_id'=>$selesman_id,
				'i_code'=>$i_code,
				'item_name'=>$item_name,
				'item_code'=>$item_code,
				'date'=>$date,
				'time'=>$time,
				);
				$query = $this->Scheme_Model->insert_fun("tbl_low_stock_alert",$dt);
			}
		}
		
		$subject  = "DRD Low Stock || $title";
		$message  = "Hi $title,<br><br> One of the customer tried to order a Medicine which is currently out of stock <br><br>";
		$message .= "Item Name : ".$item_name."<br>";
		$message .= "Item Code : ".$item_code."<br>";
		$message .= "Chemist Name : ".$chemist_name."<br>";
		if($salesman_name)
		{
			$message .= "Salesman Name : ".$salesman_name."<br>";
		}
		$message .= "<br>Please arrange a callback for the customer to place this order.";
		$message .="<br><br>Thanks<br>D R Distributors Private Limited<br><br>";
		
		/**********************************************************/
		
		if(!empty($query))
		{
			$subject = base64_encode($subject);
			$message = base64_encode($message);
			$email_function = "low_stock_alert";
			$mail_server = "";
			
			$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
			$user_email_id = $row->email;

			$dt = array(
			'user_email_id'=>$user_email_id,
			'subject'=>$subject,
			'message'=>$message,
			'email_function'=>$email_function,
			'mail_server'=>$mail_server,
			);
			$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		}
	}
	
	public function get_order_quantity_of_medicine(){
		//error_reporting(0);
		$items = "";
		$user_type 		= $this->session->userdata('user_type');
		$user_altercode	= $this->session->userdata('user_altercode');
		
		$chemist_id	= $_REQUEST["chemist_id"];
		$i_code		= $_REQUEST["i_code"];
		
		$selesman_id = "";
		if($user_type=="sales")
		{
			$selesman_id = $user_altercode;
		}
		else
		{
			$chemist_id  = $user_altercode;
		}
		
		$quantity = "";
		$where = array('chemist_id'=>$chemist_id,'selesman_id'=>$selesman_id,'user_type'=>$user_type,'i_code'=>$i_code,'status'=>'0');
		$row = $this->Scheme_Model->select_row("drd_temp_rec",$where);
		if(!empty($row->id))
		{
			$quantity = $row->quantity;
		}
		
$items .= <<<EOD
{"quantity":"{$quantity}"},
EOD;

if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
    }
	
	public function favourite_medicines_search_pg(){
		//error_reporting(0);
		$items = "";
		$user_type 		= $this->session->userdata('user_type');
		$user_altercode	= $this->session->userdata('user_altercode');
		
		$result = $this->db->query("select DISTINCT image,item_name,id,i_code,quantity, COUNT(*) as ct FROM tbl_order where chemist_id='$user_altercode' and user_type='$user_type' GROUP BY item_name HAVING COUNT(*) > 0 order by ct asc limit 10")->result();
		foreach($result as $row)
		{
			$item_code 		= ($row->i_code);
			$item_name 		= ucwords(strtolower($row->item_name));
			$quantity 		= ($row->quantity);
			$item_image 	= ($row->image);
			
$items.= <<<EOD
{"item_code":"{$item_code}","item_name":"{$item_name}","quantity":"{$quantity}","item_image":"{$item_image}"},
EOD;
        }
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
    }

	public function save_order_to_server()
	{		
		error_reporting(0);
		$items = "";
		$slice_type		= $_REQUEST["slice_type"];
		$slice_item		= $_REQUEST["slice_item"];
		$chemist_id		= $_REQUEST["chemist_id"];
		$remarks 		= $_REQUEST["remarks"];
		$user_altercode = $this->session->userdata('user_altercode');
		$user_type 		= $this->session->userdata('user_type');
		
		$selesman_id = "";
		if($user_type=="sales")
		{
			$selesman_id = $user_altercode;
		}
		else
		{
			$chemist_id  = $user_altercode;
		}		

		$status = $this->Order_Model->save_order_to_server("pc_mobile",$slice_type,$slice_item,$remarks,$selesman_id,$chemist_id,$user_type,$_SESSION["user_password"]);
		$order_success = $status[0];
		$place_order_message = base64_encode($status[1]);
		$device_id = "";
		if($order_success=="1"){
			$_SESSION["user_cart_total"] = 0;
		}
		
$items .= <<<EOD
{"order_success":"{$order_success}","device_id":"{$device_id}","chemist_id":"{$chemist_id}","selesman_id":"{$selesman_id}","user_type":"{$user_type}","place_order_message":"{$place_order_message}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}

	public function delete_medicine()
	{
		//error_reporting(0);
		$items = "";
		$id = $_REQUEST["id"];
		$response = $this->db->query("delete from drd_temp_rec where id='$id'");

$items.= <<<EOD
{"response":"{$response}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}

	public function delete_medicine_import_page()
	{
		//error_reporting(0);
		$items = "";
		$item_code 		= $_REQUEST["item_code"];
		$user_altercode = $_REQUEST["user_altercode"];
		$user_type 		= $_SESSION["user_type"];

		$selesman_id = "";
		if($user_type=="sales")
		{
			$selesman_id 	= $_SESSION['user_altercode'];
		}else{
			$user_altercode	= $_SESSION["user_altercode"];
		}

		$response = $this->db->query("delete from drd_temp_rec where i_code='$item_code' and selesman_id='$selesman_id' and chemist_id='$user_altercode' and user_type='$user_type' and status=0");

$items.= <<<EOD
{"response":"{$response}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}
	
	public function delete_all_medicine()
	{
		//error_reporting(0);
		$items = "";
		$chemist_id = $_POST["chemist_id"];
		$temp_rec = $this->get_temp_rec($chemist_id);
		$response = $this->db->query("delete from drd_temp_rec where temp_rec='$temp_rec' and status='0'");

$items.= <<<EOD
{"response":"{$response}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}
}
?>