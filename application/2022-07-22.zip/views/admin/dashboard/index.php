	<?= $this->session->flashdata('message'); ?>
	<?php
	if($this->session->userdata('user_type')!="") { ?>
	<div class="notika-status-area">
        <div class="container">
            <div class="row">
				<div class="col-xs-12">
					<div class="col-lg-3">
						<div class="widget style1 navy-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-check fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<span>Total Medicine</span>
									<h2 class="font-bold"><span class="counter"><?php echo $total_medicine ?></span></h2>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 lazur-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-thumbs-up fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_chemist">
										<span>Total Chemist</span>
										<h2 class="font-bold"><span class="counter"><?php echo $total_acm ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 yellow-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-bell fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_corporate">
										<span>Total Corporate</span>
										<h2 class="font-bold"><span class="counter"><?php echo $total_staffdetail ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 btn-danger m-r-sm">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-warning fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_salesman">
										<span>Total Salesman</span>
										<h2 class="font-bold"><span class="counter"><?php echo $total_salesman ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 navy-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-rss fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_master">
										<span>Total Rider</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_master ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 lazur-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-thumbs-up fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Today Unique Orders</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_orders3 ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 yellow-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-bell fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Today Orders</span>
										<h2 class="font-bold"><span class=""><?php echo $today_orders ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 btn-danger m-r-sm">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-warning fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Today Order Price</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_orders_price ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 navy-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-rss fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Today Order Items</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_orders_items ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 lazur-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-thumbs-up fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Today Website Order</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_website_orders_items ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 yellow-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-bell fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Total Android Order</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_android_orders_items ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 btn-danger m-r-sm">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-warning fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_orders">
										<span>Total Excel Order</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_excel_orders_items ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 navy-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-rss fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_invoice">
										<span>Today Invoice</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_invoice ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="widget style1 lazur-bg">
							<div class="row">
								<div class="col-xs-4">
									<i class="fa fa-thumbs-up fa-4x"></i>
								</div>
								<div class="col-xs-8 text-right">
									<a href="<?=base_url(); ?>admin/manage_invoice">
										<span>Today Total Sales</span>
										<h2 class="font-bold"><span class="counter"><?php echo $today_total_sales ?></span></h2>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- -->
			<div class="wrapper wrapper-content animated fadeInRight">
				<div class="row">
					<div class="col-lg-4">
						<div class="ibox float-e-margins">
							<div class="ibox-title">
								<h5>Top 10 Medicine</h5>								
							</div>
							<canvas height="140vh" width="180vw" id="barchart1"></canvas>
						</div>
					</div>
				</div>
			</div> <!-- -->
            <?php } ?>
        </div><!-- /.row -->
        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->