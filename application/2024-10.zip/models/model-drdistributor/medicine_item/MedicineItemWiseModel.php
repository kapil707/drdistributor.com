<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MedicineItemWiseModel extends CI_Model  
{
	public function __construct(){
		parent::__construct();
	}
	
	public function get_item_category_name($category_id){
		$this->db->select("name");
		$this->db->where('id',$category_id);
		$row = $this->db->get("tbl_item_category")->row();
		if(!empty($row)){
			return $row->name;
		}else{
			return "";
		}
	}
	
	public function get_medicine_item_view_api($session_yes_no,$user_nrx,$category_id,$show_out_of_stock,$get_record,$limit,$order_by_type)
	{		
		$jsonArray = array();		
		$sameid = "";

		$this->db->distinct("i_code");
		$this->db->order_by('id','desc');
		$this->db->where("status=1");
		$this->db->where("category_id='$category_id'");
		$this->db->limit("250");
		$query = $this->db->get("tbl_item_wise")->result();
		foreach ($query as $row)
		{
			$sameid.=$row->i_code.",";
		}
		$sameid = substr($sameid,0,-1);
		if(!empty($sameid))
		{
			$sameid = "i_code in(".$sameid.")";
		}		
		if(!empty($sameid))
		{
			$this->db->select("i_code,item_name,packing,salescm1,salescm2,company_name,batchqty,mrp,sale_rate,final_price,margin,featured,image1,misc_settings");
			$this->db->where($sameid);
			/************************************ */
			$where = "status=1 and `misc_settings` NOT LIKE '%gift%' and category!='g'";
			$this->db->where($where);
			if($user_nrx=="yes"){
			}else{
				$where="misc_settings!='#NRX'";
				$this->db->where($where);
			}
			/************************************ */
			if($show_out_of_stock==0){
				$this->db->where('batchqty !=', 0);
			}
			$this->db->limit($limit,$get_record);
			if($order_by_type=="RAND"){
				$this->db->order_by("RAND()");
			}else{
				$this->db->order_by('id', 'desc');
			}
			$query = $this->db->get("tbl_medicine")->result();
			foreach ($query as $row)
			{
				$item_code			=	$row->i_code;
				$item_name			=	ucwords(strtolower($row->item_name));
				$item_packing		=	$row->packing;
				$item_scheme		=	$row->salescm1."+".$row->salescm2;
				$item_company		=  	ucwords(strtolower($row->company_name));
				$item_quantity		=	$row->batchqty;
				$item_mrp			=	sprintf('%0.2f',round($row->mrp,2));
				$item_ptr			=	sprintf('%0.2f',round($row->sale_rate,2));
				$item_price			=	sprintf('%0.2f',round($row->final_price,2));
				$item_margin 		=   round($row->margin);
				$item_featured 		= 	$row->featured;
				$misc_settings =	$row->misc_settings;
				$item_stock = "";
				if($misc_settings=="#NRX" && $item_quantity>=10){
					$item_stock = "Available";
				}
				
				$item_image = base_url()."uploads/default_img.webp";
				if(!empty($row->image1))
				{
					$item_image = constant('img_url_site').$row->image1;
				}
				
				if($session_yes_no=="no"){
					$item_mrp 		= "xx.xx";
					$item_ptr 		= "xx.xx";
					$item_price		= "xx.xx";
					$item_margin 	= "xx";
				}
					
				$dt = array(
					'item_code' => $item_code,
					'item_image' => $item_image,
					'item_name' => $item_name,
					'item_packing' => $item_packing,
					'item_scheme' => $item_scheme,
					'item_company' => $item_company,
					'item_quantity' => $item_quantity,
					'item_stock' => $item_stock,
					'item_ptr' => $item_ptr,
					'item_mrp' => $item_mrp,
					'item_price' => $item_price,
					'item_margin' => $item_margin,
					'item_featured' => $item_featured,
				);
				$jsonArray[] = $dt;
			}
		}
		//$jsonString  = json_encode($jsonArray);
		
		$return["items"] = $jsonArray;
		$return["title"] = $this->get_item_category_name($category_id);
		$return["get_record"] = $get_record;
		return $return;
	}
}