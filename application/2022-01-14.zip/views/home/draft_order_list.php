<div style="width:100%;display:none;padding-top: 100px;" class="loading_pg">
	<h1 class="text-center">
		<img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px" alt="Loading...." title="Loading....">
	</h1>
	<h1 class="text-center">Loading....</h1>
	<h1 class="text-center">Please wait, Your order is under process.</h1>
</div>
<style>
.menubtn1
{
	display:none;
}
@media screen and (max-width: 767px) {
	.search_pg_menu_off,.main_home_top_btn
	{
		display: none;
	}
	.current_order_search_page,.delete_btn_icon
	{
		display: block !important;
	}
}
.headertitle
{
    margin-top: 5px !important;
}
</style>
<script>
$(".headertitle").html("Draft");
function goBack() {
	window.location.href = "<?= base_url();?>home/search_medicine";
}
</script>
<div class="container maincontainercss">
	<div class="row">
		<div class="col-sm-6 col-6 current_order_search_page1">
			<h6 class="search_pg_title_color Current_Order">Current order <span class="mycartwalidiv1"></span></h6>
		</div>
		<div class="col-sm-6 col-6 text-right current_order_search_page1" style="margin-bottom:5px;">
			<a href="#" onclick="delete_all_medicine()" tabindex="-10" class="cart_delete_btn delete_all_btn" title="Delete all medicine"> <img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" alt="Delete all medicine" title="Delete all medicine"> Delete all <span class="mobile_off">medicine</span></a>
		</div>
		<div class="col-sm-12 col-12">
			<span class="medicine_cart_list_div">
			</span>
		</div>
		<div class="col-sm-3 col-8 text-left">
			<a href="<?=base_url();?>home/search_medicine" class="btn mainbutton" style="margin-top:10px;"> 
				+ Add new medicine
			</a>
		</div>
		<div class="col-sm-1"></div>
	</div>
</div>
<div class="place_order_or_empty_cart_btn_div">
	<div class="container">
		<div class="row">
			<div class="col-12 text-center">	
				<strong style="color:red" class="cart_btn_msg">
				
				</strong>
			</div>
			<div class="col-5 text-center">				
				<div class="cart_pg_items">0 items</div>
				<div class="cart_pg_rs"><i class="fa fa-inr"></i>0.00</div>
			</div>
			<div class="col-7 text-center">
				<span class="cart_empty_cart_div">
					<i class="fa fa-circle-o-notch fa-spin" style="font-size:24px;display:none" id="order_loading"></i><button class="btn mainbutton_disable" onclick="cart_empty_btn()" tabindex="-3" title="Cart Is Empty">Cart is empty</button>
				</span>
				<span class="cart_disabled_cart_div" style="display:none">
					<em class="fa fa-circle-o-notch fa-spin" style="font-size:24px;display:none" id="order_loading"></em><button class="btn mainbutton_disable" tabindex="-3" title="Can't place order">Can't place order</button>
				</span>
				<span class="cart_add_to_cart_div" style="display:none">
					<em class="fa fa-circle-o-notch fa-spin" style="font-size:24px;display:none" id="order_loading"></em><button class="btn mainbutton" onclick="place_order_model()" tabindex="-3" title="Place order">Place order</button>
				</span>
			</div>
		</div>
	</div>
</div>
<?php if(!empty($_SESSION['user_temp_rec'])){ ?>
<input type="hidden" value="<?php echo $_SESSION["user_temp_rec"] ?>" class="user_temp_rec">
<?php } ?>
<button type="button" class="place_order_model" data-toggle="modal" data-target="#myModal_place_order" style="display:none"></button>
<!-- The Modal -->
<div class="modal" id="myModal_place_order">
	<div class="modal-dialog">
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Enter a remark</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

			<!-- Modal body -->
			<div class="modal-body">
				<div class="form-check">
					<label class="form-check-label">
					<input type="radio" class="form-check-input" name="optradio" id="slice_type0" onclick="slice_type_change('0')" checked>Complete one order
					</label>
				</div>
				<?php /*
				<div class="form-check">
					<label class="form-check-label">
					<input type="radio" class="form-check-input" name="optradio" id="slice_type1" onclick="slice_type_change('1')">Break by Amount
					</label>
				</div>
				<div class="form-check disabled">
					<label class="form-check-label">
					<input type="radio" class="form-check-input" name="optradio" id="slice_type2" onclick="slice_type_change('2')">Break by Line Quantity
					</label>
					<input type="hidden" class="form-control" id="slice_type" value="0" />
				</div>*/ ?>
				<div class="form-group slice_item1_div" style="display:none">
					<label>Break by Amount</label>
					<select class="form-control" id="slice_item1">
						<option value="9000">9000</option>
						<option value="19000">19000</option>
						<option value="49000">49000</option>
						<option value="99000">99000</option>
						<option value="199000">199000</option>
					</select>
				</div>
				<div class="form-group slice_item2_div" style="display:none">
					<label>Break by Line Quantity</label>
					<select class="form-control" id="slice_item2">
						<option value="10">10</option>
						<option value="20">20</option>
						<option value="40">40</option>
						<option value="100">100</option>
					</select>
				</div>
				<div class="form-group">
					<textarea class="form-control rounded-0 border" id="remarks" rows="5" placeholder="Enter a remark" style="border-style: solid !important;    border-color: #e0e0e0 !important;    border-width: 1px !important;"></textarea>
				</div>
			</div>

			<!-- Modal footer -->
			<div class="modal-footer">
				<button type="button" class="btn mainbutton" data-dismiss="modal" onclick="place_order_complete()">Place order</button>
			</div>
		</div>
	</div>
</div>
<script>
function slice_type_change(mtid)
{
	$(".slice_item1_div").hide();
	$(".slice_item2_div").hide();
	$("#slice_type").val(mtid);
	if(mtid=="1")
	{
		$(".slice_item1_div").show();
	}
	if(mtid=="2")
	{
		$(".slice_item2_div").show();
	}
}
$(document).ready(function(){
	setTimeout('page_load();',100);
});
function page_load()
{
	medicine_cart_list();
	place_order_or_empty_cart_btn();
}
function medicine_cart_list()
{
	$(".btn_add_medicine").show();
	mcl_i = 0;
	$(".medicine_cart_list_div").html('<h1><center><img src="<?= base_url(); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	chemist_id = "<?=$chemist_id?>";
	$.ajax({
		url: "<?php echo base_url(); ?>Chemist_order/medicine_cart_list_api",
		type:"POST",
		cache: true,
		data: {chemist_id:chemist_id},
		error: function(){
			$(".medicine_cart_list_div").html('<h1><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/something_went_wrong.png" width="100%"></h1>');
		},
		success: function(data){
			if(data.items=="")
			{
				$(".medicine_cart_list_div").html('<h1><center><img src="<?= base_url(); ?>img_v<?= constant('site_v') ?>/cartempty.png" width="50%"></center></h1>');
				$(".delete_all_btn").hide();
				$(".Current_Order").hide();
				$(".place_order_or_empty_cart_btn_div").hide();
				$(".btn_add_medicine").hide();
			}
			else
			{
				$(".medicine_cart_list_div").html("");
				$(".delete_all_btn").show();
			}
			$.each(data.items, function(i,item){
				if (item)
				{
					id 			= item.id;
					i_code 		= item.i_code;
					item_name 	= item.item_name;
					company_full_name 	= item.company_full_name;
					packing 	= item.packing;
					expiry 		= item.expiry;
					image		= item.image;
					quantity 	= item.quantity;
					sale_rate 	= item.sale_rate;
					scheme 		= item.scheme;
					modalnumber = item.modalnumber;
					datetime 	= item.datetime;
					finalpay 	= atob(item.finalpay);
					
					image_ = '<img src="'+image+'" style="width: 100%;cursor: pointer;" class="cart_image_search1" onclick="get_single_medicine_info('+i_code+')">';
					
					scheme_ = "";
					if(scheme!="0+0")
					{
						scheme_ =  '<span class="cart_scheme" title="'+item_name+' '+scheme+'">Scheme : '+scheme+'</span>';
					}

					rate_div = '<div class="cart_ki_main_div3 cart_date_time">'+modalnumber+' | '+datetime+'</div><div class="cart_ki_main_div3"><span class="cart_ptr">Price : <i class="fa fa-inr" aria-hidden="true"></i> '+sale_rate+'/-</span> | <span class="cart_total">Total : <i class="fa fa-inr" aria-hidden="true"></i> '+finalpay+'/-</span><span style="float:right;"><a href="javascript:delete_medicine('+id+','+i_code+')" tabindex="-10" title="Delete '+item_name+'"><img src="<?= base_url() ?>/img_v<?= constant('site_v') ?>/delete_icon.png" width="18px;" style="margin-top: 5px;margin-bottom: 2px;margin-right:5px;"></a>&nbsp;<a href="javascript:get_single_medicine_info('+i_code+')" tabindex="-10" title="Edit '+item_name+'" class="edit_item_focues'+i_code+'"><img src="<?= base_url() ?>/img_v<?= constant('site_v') ?>/edit_icon.png" width="18px;" style="margin-top: 5px;margin-bottom: 2px;"></a>&nbsp;&nbsp;</div>';
					
					$(".medicine_cart_list_div").append('<div class="cart_ki_main_div cart_div_bg"><div class="cart_ki_main_div1_1">'+image_+'</div><div class="cart_ki_main_div2_1"><div class="text-capitalize cart_title" title="'+item_name+'" onclick="get_single_medicine_info('+i_code+')" style="cursor: pointer;">'+item_name+' <span class="cart_packing">('+packing+' Packing)</span></div><div class="cart_expiry">Expiry : '+expiry+'</div><div class="cart_company">By '+company_full_name+'</div><div class="text-left cart_stock" title="'+item_name+' Quantity: '+quantity+'" >Order quantity : '+quantity+'</div><div class="">'+scheme_+'</div><span class="mobile_off">'+rate_div+'</span></div><span class="mobile_show" style="margin-left:5px;">'+rate_div+'</span></div>');
				}
			});
		},
		timeout: 10000
	});
}
function place_order_or_empty_cart_btn()
{
	chemist_id = "<?=$chemist_id?>";
	$('.place_order_model').hide();
	$.ajax({
		url: "<?php echo base_url(); ?>Chemist_order/place_order_or_empty_cart_btn",
		type:"POST",
		/*dataType: 'html',*/
		data: {chemist_id:chemist_id},
		error: function(){
			//$('.place_order_or_empty_cart_btn_div').html('');
		},
		success: function(data){
			//$('.place_order_or_empty_cart_btn_div').html(data);
			$.each(data.items, function(i,item){
				if (item)
				{
					rs 			= item.rs;
					items_total = item.items_total;
					cart_btn_msg = item.cart_btn_msg;
					cart_btn_status = item.cart_btn_status;
					$(".cart_pg_rs").html('<i class="fa fa-inr"></i>'+rs+'/-');
					$(".cart_pg_items").html(items_total+" Items");
					$(".cart_btn_msg").html(cart_btn_msg);
					if(items_total==0)
					{
						$(".cart_empty_cart_div").show();
						$(".cart_add_to_cart_div").hide();
						$(".cart_disabled_cart_div").hide();
					}
					if(items_total!=0)
					{
						if(cart_btn_status==1)
						{
							$(".cart_empty_cart_div").hide();
							$(".cart_add_to_cart_div").show();
							$(".cart_disabled_cart_div").hide();

							$(".cart_btn_msg").html('');
						}
						else{
							$(".cart_empty_cart_div").hide();
							$(".cart_add_to_cart_div").hide();
							$(".cart_disabled_cart_div").show();
						}
					}
				}
			});
		},
		timeout: 10000
	});
}
function place_order_model()
{
	$(".place_order_model").click();
	$("#remarks").focus();
}
function place_order_complete()
{
	chemist_id  = "<?=$chemist_id?>";
	slice_item 	= "";
	slice_type 	= $("#slice_type").val();
	if(slice_type=="1")
	{
		slice_item 	= $("#slice_item1").val();
	}
	if(slice_type=="2")
	{
		slice_item 	= $("#slice_item2").val();
	}
	remarks 	= $("#remarks").val();
	
	$(".loading_pg").show();
	$(".maincontainercss").hide();
	$(".place_order_or_empty_cart_btn_div").hide();
	
	$.ajax({
		type       : "POST",
		data       :  {slice_type:slice_type,slice_item:slice_item,chemist_id:chemist_id,remarks:remarks},
		url        : "<?php echo base_url(); ?>Chemist_order/save_order_to_server",
		cache	   : true,
		error: function(){
			window.location.href = "<?= base_url();?>home/draft_order_list";
		},
		success    : function(data){
			$.each(data.items, function(i,item){
				if (item)
				{
					order_success 	= item.order_success;
					place_order_message = atob(item.place_order_message);
					if(order_success=="0" || order_success=="1")
					{
						$(".loading_pg").html("<h1 class='text-center'>"+place_order_message+"</h1><h1 class='text-center'><input type='submit' value='Go home' class='btn mainbutton' name='Go home' onclick='gohome()' style='width:50%;margin-top:100px;'></h1>");
				    }
					count_temp_rec();
				}
			});
		},
		//timeout: 10000
	});
}

function delete_medicine(id,i_code)
{
	swal({
		title: "Are you sure to delete medicine?",
		/*text: "Once deleted, you will not be able to recover this imaginary file!",*/
		icon: "warning",
		buttons: ["No", "Yes"],
		dangerMode: true,
	}).then(function(result) {
		if (result) 
		{
			
		$.ajax({                          
			url: "<?php echo base_url(); ?>Chemist_order/delete_medicine",
			type:"POST",
			/*dataType: 'html',*/
			data: {'id': id},
			error: function(){
				swal("Medicine not deleted");
			},
			success: function(data){
				$.each(data.items, function(i,item){	
					if (item)
					{
						if(item.response=="1")
						{
							count_temp_rec();
							place_order_or_empty_cart_btn();
							//page_load();
							$(".item_focues"+i_code).html('')
							swal("Medicine deleted successfully", {
								icon: "success",
							});
						}
						else{
							swal("Medicine not deleted");
						}
					} 
				});
			},
			timeout: 10000
		});
		} else {
			swal("Medicine not deleted");
		}
	});	
}
function delete_all_medicine()
{
	swal({
		title: "Are you sure to delete all medicines?",
		/*text: "Once deleted, you will not be able to recover this imaginary file!",*/
		icon: "warning",
		buttons: ["No", "Yes"],
		dangerMode: true,
	}).then(function(result) {
		if (result) 
		{
			chemist_id = "<?=$chemist_id?>";
			$.ajax({                          
				url: "<?php echo base_url(); ?>Chemist_order/delete_all_medicine",
				type:"POST",
				/*dataType: 'html',*/
				data: {'chemist_id': chemist_id},
				error: function(){
					swal("Medicines not deleted");
				},
				success: function(data){
					$.each(data.items, function(i,item){	
						if (item)
						{
							if(item.response=="1")
							{
								count_temp_rec();
								page_load();
								swal("Medicines deleted successfully", {
									icon: "success",
								});
							}
							else{
								swal("Medicines not deleted");
							}
						} 
					});
				},
				timeout: 10000
			});
		} else {
			swal("Medicines not deleted");
		}
	});
}
function gohome()
{
	window.location.href= "<?= base_url() ?>home";
}
</script>