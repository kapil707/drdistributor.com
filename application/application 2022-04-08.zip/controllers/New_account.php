<?php
ini_set('memory_limit','-1');
ini_set('post_max_size','100M');
ini_set('upload_max_filesize','100M');
ini_set('max_execution_time',36000);
defined('BASEPATH') OR exit('No direct script access allowed');
class New_account extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//error_reporting(0);
		if($this->session->userdata('user_session')==""){
			redirect(base_url()."user/login");			
		}
		$under_construction = $this->Scheme_Model->get_website_data("under_construction");
		if($under_construction=="1")
		{
			redirect(base_url()."under_construction");
		}
	}
	
	public function file1()
	{
		////error_reporting(0);
		
		$data["session_user_image"] 	= $this->session->userdata('user_image');
		$data["session_user_fname"]     = $this->session->userdata('user_fname');
		$data["session_user_altercode"] = $this->session->userdata('user_altercode');
		//$data["chemist_id"] = $this->session->userdata('user_altercode');
		
		$data["main_page_title"] = "File 1";		
		
		$this->load->view('home/header', $data);
		$this->load->view('new_account/file1', $data);
	}
	public function upload_file1(){
		//error_reporting(0);

		$this->db->query("TRUNCATE TABLE drd_temp_file1");

		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A5', 'Company Name')
		->setCellValue('B5', 'Gst 0%')
		->setCellValue('C5', 'Value')
		->setCellValue('D5', 'Gst 5%')
		->setCellValue('E5', 'Value')
		->setCellValue('F5', 'Gst 12%')
		->setCellValue('G5', 'Value')
		->setCellValue('H5', 'Gst 18%')
		->setCellValue('I5', 'Value')
		->setCellValue('J5', 'Gst 28%')
		->setCellValue('K5', 'Value')
		->setCellValue('L5', 'Total Value')
		->setCellValue('M5', 'Inclusive Tax Total');		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);

		$items = "";
		$headername	= strtoupper($_GET['headername']);
		$companyname = strtoupper($_GET['companyname']);
		
		$gst0 		= strtoupper($_GET['gst0']);
		$gst5 		= strtoupper($_GET['gst5']);
		$gst12 		= strtoupper($_GET['gst12']);
		$gst18 		= strtoupper($_GET['gst18']);
		$gst28 		= strtoupper($_GET['gst28']);
		$totalvalue = strtoupper($_GET['totalvalue']);

		$filename = time().$_FILES['file']['name'];
		$uploadedfile = $_FILES['file']['tmp_name'];
		$upload_path = "./temp_new_account/";
		if(move_uploaded_file($uploadedfile, $upload_path.$filename))
		{			
			$excelFile = $upload_path.$filename;
			if(file_exists($excelFile))
			{
				$this->load->library('excel');
				$objPHPExcel1 = PHPExcel_IOFactory::load($excelFile);
				foreach ($objPHPExcel1->getWorksheetIterator() as $worksheet)
				{
					$rowCount = 5;
					$highestRow = $worksheet->getHighestRow();
					for ($row=$headername; $row<=$highestRow; $row++)
					{
						$companyname_ = $worksheet->getCell($companyname.$row)->getValue();
						if($companyname_!="")
						{
							$gst0_ 		 = $worksheet->getCell($gst0.$row)->getValue();
							$gst5_ 		 = $worksheet->getCell($gst5.$row)->getValue();
							$gst12_ 	 = $worksheet->getCell($gst12.$row)->getValue();
							$gst18_ 	 = $worksheet->getCell($gst18.$row)->getValue();
							$gst28_ 	 = $worksheet->getCell($gst28.$row)->getValue();
							$totalvalue_ = $worksheet->getCell($totalvalue.$row)->getValue();

							$gst0_total  = round($gst0_ * 0 , 2);
							$gst5_total  = round($gst5_ * 1.05 , 2);
							$gst12_total = round($gst12_ * 1.12 , 2);
							$gst18_total = round($gst18_ * 1.18 , 2);
							$gst28_total = round($gst28_ * 1.28 , 2);

							$inclusive_tax_total_ = $gst0_total + $gst5_total + $gst12_total + $gst18_total + $gst28_total;

							$this->db->query("insert into drd_temp_file1 (companyname,gst0,gst0_total,gst5,gst5_total,gst12,gst12_total,gst18,gst18_total,gst28,gst28_total,totalvalue,inclusive_tax_total) values ('$companyname_','$gst0_','$gst0_total','$gst5_','$gst5_total','$gst12_','$gst12_total','$gst18_','$gst18_total','$gst28_','$gst28_total','$totalvalue_','$inclusive_tax_total_')");

							/*$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$companyname_);
							$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$gst0_);
							$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$gst0_ * 0);
							$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$gst5_);
							$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,round($gst5_ * 1.05,2));
							$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$gst12_);
							$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,round($gst12_ * 1.12,2));
							$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$gst18_);
							$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount,round($gst18_ * 1.18,2));
							$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount,$gst28_);
							$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount,round($gst28_ * 1.28,2));
							$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowCount,$totalvalue_);
							$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowCount,round($gst0_ * 0,2) + round($gst5_ * 1.05,2) + round($gst12_ * 1.12,2) + round($gst18_ * 1.18,2) + round($gst28_ * 1.28,2));
							$rowCount++;*/
						}
					}
				}
				unlink($excelFile);
			}
		}
		
		/*$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "temp_new_account/new_items_".time().".xls";
		$objWriter->save($file_name);
		$url = base_url().$file_name;*/



		$url = base_url()."new_account/file2";

		header('Content-Type: application/json');
$items.= <<<EOD
{"url":"{$url}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}

	/**************************************** */
	public function file2()
	{		
		$data["session_user_image"] 	= $this->session->userdata('user_image');
		$data["session_user_fname"]     = $this->session->userdata('user_fname');
		$data["session_user_altercode"] = $this->session->userdata('user_altercode');
		
		$data["main_page_title"] = "File 2";		
		
		$this->load->view('home/header', $data);
		$this->load->view('new_account/file2', $data);
	}

	public function upload_file2(){

		$this->db->query("TRUNCATE TABLE drd_temp_file2");

		$this->load->library('excel');

		$items = "";
		$headername	= strtoupper($_GET['headername']);
		
		$code 		= strtoupper($_GET['code']);
		$name 		= strtoupper($_GET['name']);
		$flag 		= strtoupper($_GET['flag']);
		$debit 		= strtoupper($_GET['debit']);
		$credit 	= strtoupper($_GET['credit']);

		$filename = time().$_FILES['file']['name'];
		$uploadedfile = $_FILES['file']['tmp_name'];
		$upload_path = "./temp_new_account/";
		if(move_uploaded_file($uploadedfile, $upload_path.$filename))
		{			
			$excelFile = $upload_path.$filename;
			if(file_exists($excelFile))
			{
				$this->load->library('excel');
				$objPHPExcel1 = PHPExcel_IOFactory::load($excelFile);
				foreach ($objPHPExcel1->getWorksheetIterator() as $worksheet)
				{
					$highestRow = $worksheet->getHighestRow();
					for ($row=$headername; $row<=$highestRow; $row++)
					{
						$name_ = $worksheet->getCell($name.$row)->getValue();
						if($name_!="")
						{
							$code_ 		 = $worksheet->getCell($code.$row)->getValue();
							$flag_ 		 = $worksheet->getCell($flag.$row)->getValue();
							$debit_ 	 = $worksheet->getCell($debit.$row)->getValue();
							$credit_ 	 = $worksheet->getCell($credit.$row)->getValue();

							$this->db->query("insert into drd_temp_file2 (code,name,flag,debit,credit) values ('$code_','$name_','$flag_','$debit_','$credit_')");
						}
					}
				}
				unlink($excelFile);
			}
		}

		$url = base_url()."new_account/file_master";

		header('Content-Type: application/json');
$items.= <<<EOD
{"url":"{$url}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}<?php
	}

	/****************************************** */

	public function file_master()
	{		
		$data["session_user_image"] 	= $this->session->userdata('user_image');
		$data["session_user_fname"]     = $this->session->userdata('user_fname');
		$data["session_user_altercode"] = $this->session->userdata('user_altercode');
		
		$data["main_page_title"] = "New Account";		
		
		$this->load->view('home/header', $data);
		$this->load->view('new_account/file1', $data);
	}
	/**********************************************/
	public function download_master_file(){
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		ob_clean();		

		date_default_timezone_set('Asia/Calcutta');
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A3', 'ALI')
		->setCellValue('B3', 'NAME OF COMPANY')
		->setCellValue('C3', 'SALE')
		->setCellValue('D3', 'SALE RETURN')
		->setCellValue('E3', 'NET SALES')
		->setCellValue('F3', 'CL.STOCK')
		->setCellValue('G3', 'SALE+GST')
		->setCellValue('H3', 'LEDGER BALANCE')
		->setCellValue('I3', 'STOCK + GST')
		->setCellValue('J3', 'LEDGER- STOCK')
		->setCellValue('K3', 'EXPIRY AMOUNT DUE & ( MONTH)')
		->setCellValue('L3', 'EXPIRY MORE THAN 3 MONTHS')
		->setCellValue('M3', 'FINAL');		

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(1);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(1);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(1);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(1);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(16);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(14);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);

		
		$rowCount = 3;
		$result = $this->db->query("SELECT * from drd_temp_file1 as f1 right join drd_temp_file2 as f2 on f1.companyname = f2.name")->result();
		foreach ($result as $row)
		{
			$rowCount++;
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"");
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->name);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->credit);
			if($row->debit!=0)
			{
				$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->debit);
			}
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount,$row->inclusive_tax_total);
			$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount,round($row->credit,2) - round($row->inclusive_tax_total,2));
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
		$file_name = "temp_new_account/new_items_".time().".xls";
		$objWriter->save($file_name);
		echo base_url().$file_name;
	}

	public function expiry_check($expiry)
	{
		$dt = date("y.m.d");
		$time = strtotime($dt);
		$y = date("ym", strtotime("+6 month", $time));
		$expiry1 = substr($expiry,0,2);
		$expiry2 = substr($expiry,3,5);
		$x = $expiry2.$expiry1;
		if($y<=$x)
		{
			$r = 0;
		}
		else
		{
			$r = 1;
		}
		return $r;
	}
}
?>